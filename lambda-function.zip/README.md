# lambda-function
Basic setup for using the Lambda AWS middleware functions
